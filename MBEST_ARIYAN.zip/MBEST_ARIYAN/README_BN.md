# MBEST ARIYAN

- অ্যাপে ট্যাপ করলেই ব্রাউজারে **Messenger** (messenger.com) খোলে
- **Desktop mode** সবসময় অটোমেটিক চালু
- উপরে শুধু একটা **Extension** বাটন: ZIP ফাইল যোগ, চালু/বন্ধ, মুছে ফেলা
- আর কিছু নেই

## APK বানানো
1. ফোল্ডারটি GitHub repository-তে আপলোড করুন
2. **Actions → Build MBEST ARIYAN APK → Run workflow**
3. শেষে `MBEST-ARIYAN-debug-apk` থেকে `app-debug.apk` নামান

অথবা Android Studio-তে ফোল্ডারটি Open করে **Build > Build APK(s)**।

নোট: এই পরিবেশে Android SDK নেই, তাই APK build করে টেস্ট করা যায়নি। প্রথম build-এ কোনো error এলে আমাকে পাঠান।
