package com.dragon.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * MBEST ARIYAN
 * - অ্যাপ খুললেই ব্রাউজারে Messenger খোলে
 * - সবসময় Desktop mode চালু
 * - উপরে শুধু একটা Extension বাটন (ZIP ফাইল যোগ / চালু-বন্ধ / মুছা)
 */
public class MainActivity extends Activity {

    static final String EXT_HOST = "dm.ext";
    private static final String HOME = "https://www.messenger.com";

    private static final int REQ_FILE = 11;
    private static final int REQ_ZIP = 12;
    private static final int REQ_PERM = 13;
    private static final int REQ_STORAGE = 14;

    // state used by Bridge
    Ext ext;
    volatile int curId = 1;
    volatile String curUrl = "";
    volatile String curTitle = "";

    private boolean docStart;
    private String desktopUA;

    private FrameLayout rootFrame;
    private WebView web;
    private ProgressBar progress;

    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingPerm;
    private String[] pendingDl;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    private final Map<WebView, ScriptHandler> handles = new HashMap<>();
    private final Map<String, BgPage> bgs = new HashMap<>();
    private final ArrayList<WebView> popupViews = new ArrayList<>();
    private final Map<Integer, Pending> pending = new HashMap<>();
    private int respSeq = 0;

    static final class BgPage {
        String extId;
        WebView wv;
        boolean loaded;
        final ArrayList<Runnable> queue = new ArrayList<>();

        void post(Runnable r) {
            if (loaded) r.run();
            else queue.add(r);
        }
    }

    static final class Pending {
        final WeakReference<WebView> wv;
        final int cb;

        Pending(WebView w, int cb) {
            this.wv = new WeakReference<>(w);
            this.cb = cb;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ext = new Ext(this);

        // Desktop mode সবসময় চালু: Windows Chrome-এর User-Agent
        String def = WebSettings.getDefaultUserAgent(this);
        Matcher m = Pattern.compile("Chrome/([\\d.]+)").matcher(def);
        String ver = m.find() ? m.group(1) : "120.0.0.0";
        desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + ver + " Safari/537.36";

        boolean ds = false;
        try {
            ds = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        } catch (Throwable ignored) {
        }
        docStart = ds;

        buildUi();
        setupWebView();
        refreshExtensions();
        web.loadUrl(HOME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (web != null) web.destroy();
        } catch (Exception ignored) {
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            moveTaskToBack(true);
        }
    }

    // ------------------------------------------------------------------ UI

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void buildUi() {
        rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(Color.BLACK);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setFitsSystemWindows(true);

        // উপরের পাতলা বার — শুধু Extension বাটন
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        bar.setBackgroundColor(0xFF17181B);
        bar.setPadding(dp(8), 0, dp(8), 0);

        TextView btn = new TextView(this);
        btn.setText("Extension");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(6), dp(16), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF2A2C33);
        bg.setCornerRadius(dp(16));
        btn.setBackground(bg);
        btn.setOnClickListener(v -> showExtMenu());
        bar.addView(btn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);

        web = new WebView(this);

        main.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        main.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        main.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        rootFrame.addView(main, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootFrame);
    }

    // ------------------------------------------------------------------ WebView

    private void setupWebView() {
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        s.setUserAgentString(desktopUA);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        Bridge br = new Bridge(this, "tab", curId);
        br.attach(web);
        web.addJavascriptInterface(br, "__DM");
        installBootstrap(web, ext.tabBootstrap());

        web.setWebViewClient(new MainClient());
        web.setWebChromeClient(new MainChrome());
        web.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));
    }

    private void dropHandle(WebView w) {
        ScriptHandler h = handles.remove(w);
        if (h != null) {
            try {
                h.remove();
            } catch (Throwable ignored) {
            }
        }
    }

    private void installBootstrap(WebView w, String js) {
        dropHandle(w);
        if (!docStart) return;
        try {
            ScriptHandler h = WebViewCompat.addDocumentStartJavaScript(w, js, Collections.singleton("*"));
            handles.put(w, h);
        } catch (Throwable ignored) {
        }
    }

    void openUrlInNewTab(final String url) {
        if (url == null || url.length() == 0) return;
        runOnUiThread(() -> web.loadUrl(url));
    }

    private boolean handleExternal(String u) {
        if (u == null) return false;
        if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")
                || u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("javascript:")
                || u.startsWith("file:")) {
            return false;
        }
        try {
            Intent i;
            if (u.startsWith("intent:")) {
                i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
            } else {
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            }
            startActivity(i);
        } catch (Exception e) {
            toast("এই লিংক খোলা গেল না");
        }
        return true;
    }

    private final class MainClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            if (x != null) return x;
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleExternal(r.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            curUrl = url == null ? "" : url;
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.tabBootstrap(), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            curUrl = url == null ? "" : url;
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                String u = r.getUrl().toString();
                String page = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;text-align:center;padding:40px 16px;background:#000;color:#ddd'>"
                        + "<h2>পেজ লোড হয়নি</h2><p>ইন্টারনেট চেক করে আবার চেষ্টা করুন।</p>"
                        + "<p style='color:#999;font-size:13px'>" + TextUtils.htmlEncode(String.valueOf(e.getDescription())) + "</p>"
                        + "<button onclick='location.replace(" + TextUtils.htmlEncode(JSONObject.quote(u)) + ")' "
                        + "style='margin-top:14px;padding:12px 28px;border:0;border-radius:12px;background:#1a73e8;color:#fff;font-size:16px'>"
                        + "আবার চেষ্টা</button></body></html>";
                v.loadDataWithBaseURL(u, page, "text/html", "utf-8", u);
            }
        }
    }

    private final class MainChrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            progress.setProgress(p);
            progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            curTitle = title == null ? "" : title;
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> handlePermission(req));
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            rootFrame.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        rootFrame.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ------------------------------------------------------------------ camera / mic

    private void handlePermission(PermissionRequest req) {
        ArrayList<String> need = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            req.grant(req.getResources());
            return;
        }
        if (pendingPerm != null) pendingPerm.deny();
        pendingPerm = req;
        requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_STORAGE) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            String[] d = pendingDl;
            pendingDl = null;
            if (ok && d != null) startDownload(d[0], d[1], d[2], d[3]);
            else if (!ok) toast("ডাউনলোড করতে স্টোরেজ পারমিশন লাগবে");
            return;
        }
        if (code != REQ_PERM || pendingPerm == null) return;
        PermissionRequest req = pendingPerm;
        pendingPerm = null;
        ArrayList<String> ok = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            }
        }
        if (ok.isEmpty()) req.deny();
        else req.grant(ok.toArray(new String[0]));
    }

    // ------------------------------------------------------------------ download

    private void startDownload(String url, String ua, String cd, String mime) {
        if (url == null) return;
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("এই ধরনের ডাউনলোড সাপোর্ট করে না");
            return;
        }
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDl = new String[]{url, ua, cd, mime};
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            return;
        }
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && mime.length() > 0) r.setMimeType(mime);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            String name = URLUtil.guessFileName(url, cd, mime);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            toast("ডাউনলোড শুরু: " + name);
        } catch (Exception e) {
            toast("ডাউনলোড ব্যর্থ");
        }
    }

    // ------------------------------------------------------------------ Extension button

    private void showExtMenu() {
        final List<Ext.Info> list = ext.list();
        ArrayList<String> labels = new ArrayList<>();
        labels.add("＋  Extension ZIP ফাইল যোগ করুন");
        for (Ext.Info i : list) {
            labels.add((i.enabled ? "●  " : "○  ") + i.name
                    + (i.version != null && i.version.length() > 0 ? "  v" + i.version : ""));
        }
        new AlertDialog.Builder(this)
                .setTitle("Extension")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    if (which == 0) pickZip();
                    else extActions(list.get(which - 1));
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private void extActions(final Ext.Info e) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        if (e.popupPath() != null) {
            labels.add("খুলুন (Popup)");
            acts.add(() -> openPopup(e));
        }
        labels.add(e.enabled ? "বন্ধ করুন" : "চালু করুন");
        acts.add(() -> {
            ext.setEnabled(e.id, !e.enabled);
            onExtensionsChanged();
        });
        labels.add("মুছে ফেলুন");
        acts.add(() -> {
            ext.delete(e.id);
            onExtensionsChanged();
        });
        new AlertDialog.Builder(this)
                .setTitle(e.name)
                .setItems(labels.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream"});
        try {
            startActivityForResult(i, REQ_ZIP);
        } catch (Exception e) {
            toast("ফাইল পিকার খোলা গেল না");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCb != null) {
                Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        } else if (req == REQ_ZIP) {
            if (res == RESULT_OK && data != null && data.getData() != null) installZip(data.getData());
        }
    }

    private void installZip(final Uri uri) {
        toast("Extension যোগ হচ্ছে...");
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception("ফাইল পড়া যায়নি");
                final Ext.Info info;
                try {
                    info = ext.install(in);
                } finally {
                    in.close();
                }
                runOnUiThread(() -> {
                    toast("যোগ হয়েছে: " + (info == null ? "" : info.name));
                    onExtensionsChanged();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> toast("ZIP কাজ করেনি: " + e.getMessage()));
            }
        }).start();
    }

    private void onExtensionsChanged() {
        refreshExtensions();
        web.reload();
    }

    /** Rebuilds background pages and re-registers the content-script bootstrap in the page. */
    private void refreshExtensions() {
        for (BgPage b : bgs.values()) {
            rootFrame.removeView(b.wv);
            dropHandle(b.wv);
            try {
                b.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        bgs.clear();
        for (Ext.Info i : ext.list()) {
            if (i.enabled && i.hasBackground()) createBg(i);
        }
        installBootstrap(web, ext.tabBootstrap());
    }

    // ------------------------------------------------------------------ extension pages (background / popup)

    private void configureExtWebView(WebView w, String kind, String extId) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        Bridge br = new Bridge(this, kind, 0);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        installBootstrap(w, ext.pageBootstrap(extId));
    }

    private final class ExtPageClient extends WebViewClient {
        private final String extId;
        private final Runnable onFinish;

        ExtPageClient(String extId, Runnable onFinish) {
            this.extId = extId;
            this.onFinish = onFinish;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            return x != null ? x : super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap f) {
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.pageBootstrap(extId), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (onFinish != null) onFinish.run();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (EXT_HOST.equals(r.getUrl().getHost())) return false;
            openUrlInNewTab(r.getUrl().toString());
            return true;
        }
    }

    private void createBg(Ext.Info i) {
        final BgPage b = new BgPage();
        b.extId = i.id;
        b.wv = new WebView(this);
        configureExtWebView(b.wv, "bg", i.id);
        b.wv.setWebViewClient(new ExtPageClient(i.id, () -> {
            if (!b.loaded) {
                b.loaded = true;
                ArrayList<Runnable> q = new ArrayList<>(b.queue);
                b.queue.clear();
                for (Runnable r : q) r.run();
            }
        }));
        b.wv.setAlpha(0f);
        rootFrame.addView(b.wv, new FrameLayout.LayoutParams(1, 1));
        bgs.put(i.id, b);
        b.wv.loadUrl("https://" + EXT_HOST + Ext.PREFIX + i.id + "/_bg.html");
    }

    private void openPopup(Ext.Info e) {
        String p = e.popupPath();
        if (p == null) {
            toast("এই Extension-এ popup নেই");
            return;
        }
        final Dialog d = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("✕   " + e.name);
        title.setTextColor(0xFFE3E5EA);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(14), 0, dp(14), 0);
        title.setBackgroundColor(0xFF202226);
        title.setOnClickListener(v -> d.dismiss());

        final WebView w = new WebView(this);
        w.setBackgroundColor(Color.BLACK);
        configureExtWebView(w, "popup", e.id);
        w.setWebViewClient(new ExtPageClient(e.id, null));
        popupViews.add(w);

        box.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        box.addView(w, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        d.setContentView(box);
        d.setOnDismissListener(x -> {
            popupViews.remove(w);
            dropHandle(w);
            try {
                w.destroy();
            } catch (Exception ignored) {
            }
        });
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        w.loadUrl("https://" + EXT_HOST + Ext.PREFIX + e.id + "/" + p);
    }

    // ------------------------------------------------------------------ message routing (called by Bridge)

    private String senderJson(Bridge from, String extId) {
        JSONObject s = new JSONObject();
        try {
            s.put("id", extId);
            if ("tab".equals(from.kindName())) {
                JSONObject tb = new JSONObject();
                tb.put("id", curId);
                tb.put("url", curUrl == null ? "" : curUrl);
                tb.put("title", curTitle == null ? "" : curTitle);
                s.put("tab", tb);
                s.put("frameId", 0);
                s.put("url", curUrl == null ? "" : curUrl);
            }
        } catch (JSONException ignored) {
        }
        return s.toString();
    }

    void route(final Bridge from, final String extId, final String target, final int destTab,
               final String msg, final int cbId) {
        runOnUiThread(() -> {
            final int rid = ++respSeq;
            pending.put(rid, new Pending(from.webView(), cbId));
            final String sender = senderJson(from, extId);
            if ("bg".equals(target)) {
                final BgPage b = bgs.get(extId);
                if (b == null) {
                    respond(rid, "null");
                    return;
                }
                b.post(() -> deliver(b.wv, extId, msg, sender, rid));
            } else {
                deliver(web, extId, msg, sender, rid);
            }
        });
    }

    private void deliver(WebView dest, String extId, String msg, String sender, final int rid) {
        String js = "(window.__dmDeliver?(window.__dmDeliver(" + JSONObject.quote(extId) + ","
                + JSONObject.quote(msg == null ? "null" : msg) + "," + JSONObject.quote(sender) + "," + rid + "),1):0)";
        dest.evaluateJavascript(js, value -> {
            if (!"1".equals(value)) respond(rid, "null");
        });
    }

    void respond(final int rid, final String json) {
        runOnUiThread(() -> {
            Pending p = pending.remove(rid);
            if (p == null) return;
            WebView w = p.wv.get();
            if (w != null) {
                w.evaluateJavascript("window.__dmCb&&window.__dmCb(" + p.cb + ","
                        + JSONObject.quote(json == null ? "null" : json) + ")", null);
            }
        });
    }

    void broadcastChanges(final String extId, final String changesJson) {
        runOnUiThread(() -> {
            final String js = "window.__dmChanged&&window.__dmChanged(" + JSONObject.quote(extId) + ","
                    + JSONObject.quote(changesJson) + ",'local')";
            web.evaluateJavascript(js, null);
            for (final BgPage b : bgs.values()) b.post(() -> b.wv.evaluateJavascript(js, null));
            for (WebView w : new ArrayList<>(popupViews)) w.evaluateJavascript(js, null);
        });
    }
}
